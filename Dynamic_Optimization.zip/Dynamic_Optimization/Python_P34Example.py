import numpy as np
from scipy.optimize import minimize

# Objective function: f(x, y, z) = exp(x) + (y * z)^2
def objective(vars):
    x, y, z = vars
    return np.exp(x) + (y * z) ** 2

# Inequality constraint: x > y --> y - x < 0
def ineq_constraint(vars):
    x, y, z = vars
    return x - y  # scipy expects: g(x) >= 0 ， if no? then 0.

# Equality constraint: y = 2z --> y - 2z = 0
def eq_constraint(vars):
    x, y, z = vars
    return y - 2 * z

# Initial guess
x0 = [1.0, 1.0, 0.5]

# Constraints as dicts
constraints = [
    {'type': 'ineq', 'fun': ineq_constraint},  # x - y ≥ 0 ⇔ x > y
    {'type': 'eq', 'fun': eq_constraint}       # y = 2z
]

# Solve the optimization problem
result = minimize(objective, x0, constraints=constraints, method='SLSQP')

# Print results
if result.success:
    x_opt, y_opt, z_opt = result.x
    print("Optimal solution found:")
    print(f"x = {x_opt:.4f}")
    print(f"y = {y_opt:.4f}")
    print(f"z = {z_opt:.4f}")
    print(f"Minimum value = {result.fun:.4f}")
else:
    print("Optimization failed:", result.message)