import numpy as np
from scipy.optimize import minimize

# Objective function
def objective(vars):
    x, y, z = vars
    return np.exp(x) + (y * z) ** 2

# Nonlinear inequality: x > e^y ⇨ x - exp(y) > 0
def ineq_constraint(vars):
    x, y, z = vars
    return x - np.exp(y)  # Should be ≥ 0

# Nonlinear equality: y = z^3 ⇨ y - z^3 = 0
def eq_constraint(vars):
    x, y, z = vars
    return y - z ** 3

# Initial guess (must satisfy constraints or be close)
x0 = [2.0, 1.0, 1.0]  # x > e^y ≈ 2.718, so x0[0] must be > exp(1)

# Define constraints in scipy format
constraints = [
    {'type': 'ineq', 'fun': ineq_constraint},
    {'type': 'eq', 'fun': eq_constraint}
]

# Optimization
result = minimize(objective, x0, constraints=constraints, method='SLSQP')

# Output
if result.success:
    
    x_opt, y_opt, z_opt = result.x
    print("✅ Optimal solution found:")
    print(f"x = {x_opt:.4f}")
    print(f"y = {y_opt:.4f}")
    print(f"z = {z_opt:.4f}")
    print(f"Minimum value = {result.fun:.4f}")
else:
    print("❌ Optimization failed:", result.message)