% Objective function
f = @(x) exp(x(1)) + (x(2) * x(3))^2;  % x = [x, y, z]

% Initial guess
x0 = [1; 1; 1];

% Optimization options
options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');

% Call fmincon
[x_opt, fval] = fmincon(f, x0, [], [], [], [], [], [], @nonlcon, options);

% Display result
fprintf('\nOptimal solution:\n');
fprintf('x = %.4f\n', x_opt(1));
fprintf('y = %.4f\n', x_opt(2));
fprintf('z = %.4f\n', x_opt(3));
fprintf('Minimum value = %.4f\n', fval);

% Nonlinear constraint function
function [c, ceq] = nonlcon(x)
    % Inequality constraint: x > exp(y) ⇒ exp(y) - x ≤ 0
    c = exp(x(2)) - x(1);
    
    % Equality constraint: y = z^3 ⇒ y - z^3 = 0
    ceq = x(2) - x(3)^3;
end