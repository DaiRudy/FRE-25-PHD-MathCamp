% Objective function
f = @(x) exp(x(1)) + (x(2) * x(3))^2;

% Initial guess
x0 = [1; 1; 0.5];  % [x, y, z]

% Inequality constraints: A * x ≤ b --> x - y > 0 → -x + y < 0 → A = [-1 1 0], b = 0
A = [-1 1 0];
b = 0;

% Equality constraints: y = 2z → y - 2z = 0 → Aeq = [0 1 -2]
Aeq = [0 1 -2];
beq = 0;

% Call fmincon
options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');

[x_opt, fval] = fmincon(f, x0, A, b, Aeq, beq, [], [], [], options);

% Display result
fprintf('Optimal solution:\n');
fprintf('x = %.4f\n', x_opt(1));
fprintf('y = %.4f\n', x_opt(2));
fprintf('z = %.4f\n', x_opt(3));
fprintf('Minimum value = %.4f\n', fval);